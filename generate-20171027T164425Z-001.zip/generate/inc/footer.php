	</body>
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
	<script type="text/javascript" src="js/jquery-ui.js"></script>
	<script type="text/javascript" src="js/common.js"></script>
</html>